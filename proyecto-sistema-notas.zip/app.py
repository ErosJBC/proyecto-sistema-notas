import functions as f

url_id = "https://buscador.orcebot.com/codigos.json"
url_photo = "https://www.orce.uni.edu.pe/fotosuni/0060"

# Get list of students
f.getStudents(url_id=url_id, url_photo=url_photo)
